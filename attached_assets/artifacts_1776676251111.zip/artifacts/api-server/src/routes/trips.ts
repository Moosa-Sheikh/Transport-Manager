import { Router, type IRouter, type Request, type Response } from "express";
import { db } from "@workspace/db";
import {
  tripsTable, trucksTable, driversTable, citiesTable,
  tripLoadsTable, customersTable,
  tripExpensesTable, expenseTypesTable,
  customerPaymentsTable, driverAdvancesTable, cashBookTable,
  customerDuesTable,
} from "@workspace/db/schema";
import { eq, and, gte, lte, sql, type SQL } from "drizzle-orm";
import { alias } from "drizzle-orm/pg-core";
import { parseId } from "../lib/validate-id.js";

const fromCities = alias(citiesTable, "from_city");
const toCities = alias(citiesTable, "to_city");

const router: IRouter = Router();

const incomeSubquery = sql<number>`COALESCE((
  SELECT SUM(COALESCE(freight, 0) + COALESCE(loading_charges, 0) + COALESCE(unloading_charges, 0) - COALESCE(broker_commission, 0))
  FROM trip_loads WHERE trip_loads.trip_id = ${tripsTable.id}
), 0)::double precision`;

const expenseSubquery = sql<number>`COALESCE((
  SELECT SUM(COALESCE(amount, 0))
  FROM trip_expenses WHERE trip_expenses.trip_id = ${tripsTable.id}
), 0)::double precision`;

const totalReceivedSubquery = sql<number>`COALESCE((
  SELECT SUM(COALESCE(amount, 0))
  FROM customer_payments WHERE customer_payments.trip_id = ${tripsTable.id}
), 0)::double precision`;

const totalAdvancesSubquery = sql<number>`COALESCE((
  SELECT SUM(COALESCE(amount, 0))
  FROM driver_advances WHERE driver_advances.trip_id = ${tripsTable.id}
), 0)::double precision`;

function buildTripQuery() {
  return db
    .select({
      id: tripsTable.id,
      tripDate: tripsTable.tripDate,
      truckId: tripsTable.truckId,
      truckNumber: trucksTable.truckNumber,
      driverId: tripsTable.driverId,
      driverName: driversTable.name,
      fromCityId: tripsTable.fromCityId,
      fromCityName: fromCities.name,
      toCityId: tripsTable.toCityId,
      toCityName: toCities.name,
      driverCommission: tripsTable.driverCommission,
      status: tripsTable.status,
      createdAt: tripsTable.createdAt,
      income: incomeSubquery.as("income"),
      expense: expenseSubquery.as("expense"),
      profit: sql<number>`(${incomeSubquery} - ${expenseSubquery})::double precision`.as("profit"),
      totalReceived: totalReceivedSubquery.as("total_received"),
      totalAdvances: totalAdvancesSubquery.as("total_advances"),
      actualProfit: sql<number>`(${incomeSubquery} - ${expenseSubquery} - ${totalAdvancesSubquery})::double precision`.as("actual_profit"),
    })
    .from(tripsTable)
    .innerJoin(trucksTable, eq(tripsTable.truckId, trucksTable.id))
    .innerJoin(driversTable, eq(tripsTable.driverId, driversTable.id))
    .innerJoin(fromCities, eq(tripsTable.fromCityId, fromCities.id))
    .innerJoin(toCities, eq(tripsTable.toCityId, toCities.id));
}

router.get("/", async (req: Request, res: Response) => {
  try {
    const { date_from, date_to, truck_id, driver_id, status, profit, from_city_id, to_city_id } = req.query;
    const conditions: SQL[] = [];

    if (typeof date_from === "string" && date_from) {
      conditions.push(gte(tripsTable.tripDate, date_from));
    }
    if (typeof date_to === "string" && date_to) {
      conditions.push(lte(tripsTable.tripDate, date_to));
    }
    if (typeof truck_id === "string" && truck_id) {
      const tid = Number(truck_id);
      if (Number.isFinite(tid) && tid > 0) {
        conditions.push(eq(tripsTable.truckId, tid));
      }
    }
    if (typeof driver_id === "string" && driver_id) {
      const did = Number(driver_id);
      if (Number.isFinite(did) && did > 0) {
        conditions.push(eq(tripsTable.driverId, did));
      }
    }
    if (typeof from_city_id === "string" && from_city_id) {
      const fcid = Number(from_city_id);
      if (Number.isFinite(fcid) && fcid > 0) {
        conditions.push(eq(tripsTable.fromCityId, fcid));
      }
    }
    if (typeof to_city_id === "string" && to_city_id) {
      const tcid = Number(to_city_id);
      if (Number.isFinite(tcid) && tcid > 0) {
        conditions.push(eq(tripsTable.toCityId, tcid));
      }
    }
    if (typeof status === "string" && (status === "Open" || status === "Closed")) {
      conditions.push(eq(tripsTable.status, status));
    }

    const query = buildTripQuery();
    let rows = conditions.length > 0
      ? await query.where(and(...conditions)).orderBy(sql`${tripsTable.tripDate} DESC`)
      : await query.orderBy(sql`${tripsTable.tripDate} DESC`);

    if (typeof profit === "string") {
      if (profit === "positive") {
        rows = rows.filter((r) => r.profit > 0);
      } else if (profit === "negative") {
        rows = rows.filter((r) => r.profit < 0);
      }
    }

    res.json(rows);
  } catch (err) {
    req.log.error({ err }, "List trips error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/", async (req: Request, res: Response) => {
  try {
    const { tripDate, truckId, driverId, fromCityId, toCityId, driverCommission } = req.body;

    if (!tripDate || !truckId || !driverId || !fromCityId || !toCityId) {
      res.status(400).json({ error: "All fields are required" });
      return;
    }

    const numTruckId = Number(truckId);
    const numDriverId = Number(driverId);
    const numFromCityId = Number(fromCityId);
    const numToCityId = Number(toCityId);

    if (
      !Number.isInteger(numTruckId) ||
      !Number.isInteger(numDriverId) ||
      !Number.isInteger(numFromCityId) ||
      !Number.isInteger(numToCityId)
    ) {
      res.status(400).json({ error: "Invalid ID values" });
      return;
    }

    if (numFromCityId === numToCityId) {
      res.status(400).json({ error: "From city and To city cannot be the same" });
      return;
    }

    const commissionVal = driverCommission !== undefined && driverCommission !== null && driverCommission !== ""
      ? String(driverCommission) : "0";

    const [inserted] = await db
      .insert(tripsTable)
      .values({
        tripDate: String(tripDate),
        truckId: numTruckId,
        driverId: numDriverId,
        fromCityId: numFromCityId,
        toCityId: numToCityId,
        driverCommission: commissionVal,
      })
      .returning();

    const [row] = await buildTripQuery().where(eq(tripsTable.id, inserted.id));
    res.status(201).json(row);
  } catch (err) {
    req.log.error({ err }, "Create trip error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/:id", async (req: Request, res: Response) => {
  try {
    const id = parseId(req, res);
    if (id === null) return;

    const [row] = await buildTripQuery().where(eq(tripsTable.id, id));
    if (!row) {
      res.status(404).json({ error: "Trip not found" });
      return;
    }
    res.json(row);
  } catch (err) {
    req.log.error({ err }, "Get trip error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.put("/:id/close", async (req: Request, res: Response) => {
  try {
    const id = parseId(req, res);
    if (id === null) return;

    const [existing] = await db.select().from(tripsTable).where(eq(tripsTable.id, id));
    if (!existing) {
      res.status(404).json({ error: "Trip not found" });
      return;
    }
    if (existing.status === "Closed") {
      res.status(400).json({ error: "Trip is already closed" });
      return;
    }

    await db.transaction(async (tx) => {
      await tx.update(tripsTable).set({ status: "Closed" }).where(eq(tripsTable.id, id));

      const loads = await tx
        .select({
          id: tripLoadsTable.id,
          customerId: tripLoadsTable.customerId,
          biltyNumber: tripLoadsTable.biltyNumber,
          freight: tripLoadsTable.freight,
          loadingCharges: tripLoadsTable.loadingCharges,
          unloadingCharges: tripLoadsTable.unloadingCharges,
          brokerCommission: tripLoadsTable.brokerCommission,
        })
        .from(tripLoadsTable)
        .where(eq(tripLoadsTable.tripId, id));

      const payments = await tx
        .select({
          customerId: customerPaymentsTable.customerId,
          total: sql<number>`COALESCE(SUM(amount::numeric), 0)::double precision`,
        })
        .from(customerPaymentsTable)
        .where(eq(customerPaymentsTable.tripId, id))
        .groupBy(customerPaymentsTable.customerId);

      const customerPaid = new Map<number | null, number>();
      for (const p of payments) {
        customerPaid.set(p.customerId, (customerPaid.get(p.customerId) ?? 0) + p.total);
      }

      const unattributedPaid = customerPaid.get(null) ?? 0;

      const customerLoadIncomes = new Map<number, { totalIncome: number; loads: typeof loads }>();
      for (const load of loads) {
        const loadIncome = calcNetLoadIncome(load);
        const entry = customerLoadIncomes.get(load.customerId);
        if (entry) {
          entry.totalIncome += loadIncome;
          entry.loads.push(load);
        } else {
          customerLoadIncomes.set(load.customerId, { totalIncome: loadIncome, loads: [load] });
        }
      }

      let totalIncomeAll = 0;
      for (const data of customerLoadIncomes.values()) {
        totalIncomeAll += data.totalIncome;
      }

      for (const [custId, data] of customerLoadIncomes) {
        const attributedPaid = customerPaid.get(custId) ?? 0;
        const unattributedShare = totalIncomeAll > 0
          ? (data.totalIncome / totalIncomeAll) * unattributedPaid
          : 0;
        const totalPaidForCustomer = attributedPaid + unattributedShare;
        const customerOutstanding = data.totalIncome - totalPaidForCustomer;

        if (customerOutstanding <= 0.01) continue;

        for (const load of data.loads) {
          const loadIncome = calcNetLoadIncome(load);
          const loadDue = data.totalIncome > 0
            ? Math.round((loadIncome / data.totalIncome) * customerOutstanding * 100) / 100
            : 0;

          if (loadDue > 0.01) {
            await tx.insert(customerDuesTable).values({
              tripId: id,
              loadId: load.id,
              customerId: custId,
              biltyNumber: load.biltyNumber,
              dueAmount: String(loadDue),
              dueDate: existing.tripDate,
              notes: `Auto-generated on trip #${id} close`,
            });
          }
        }
      }
    });

    const [row] = await buildTripQuery().where(eq(tripsTable.id, id));
    res.json(row);
  } catch (err) {
    req.log.error({ err }, "Close trip error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.delete("/:id", async (req: Request, res: Response) => {
  try {
    const id = parseId(req, res);
    if (!id) return;

    const [trip] = await db.select().from(tripsTable).where(eq(tripsTable.id, id));
    if (!trip) { res.status(404).json({ error: "Trip not found" }); return; }

    if (trip.status === "Closed") {
      res.status(400).json({ error: "Cannot delete a closed trip" });
      return;
    }

    await db.transaction(async (tx) => {
      await tx.delete(customerPaymentsTable).where(eq(customerPaymentsTable.tripId, id));
      await tx.delete(driverAdvancesTable).where(eq(driverAdvancesTable.tripId, id));
      await tx.delete(tripExpensesTable).where(eq(tripExpensesTable.tripId, id));
      await tx.delete(tripLoadsTable).where(eq(tripLoadsTable.tripId, id));
      await tx.delete(cashBookTable).where(
        and(
          eq(cashBookTable.referenceTable, "trips"),
          eq(cashBookTable.referenceId, id)
        )
      );
      await tx.delete(tripsTable).where(eq(tripsTable.id, id));
    });

    res.json({ message: "Trip deleted successfully" });
  } catch (err) {
    req.log.error({ err }, "Delete trip error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.put("/:id/commission", async (req: Request, res: Response) => {
  try {
    const id = parseId(req, res);
    if (id === null) return;

    const [existing] = await db.select().from(tripsTable).where(eq(tripsTable.id, id));
    if (!existing) {
      res.status(404).json({ error: "Trip not found" });
      return;
    }
    if (existing.status === "Closed") {
      res.status(400).json({ error: "Cannot update commission on a closed trip" });
      return;
    }

    const { driverCommission } = req.body;
    const numVal = Number(driverCommission);
    if (!Number.isFinite(numVal) || numVal < 0) {
      res.status(400).json({ error: "Driver commission must be a valid non-negative number" });
      return;
    }

    await db.update(tripsTable).set({ driverCommission: String(numVal) }).where(eq(tripsTable.id, id));

    const [row] = await buildTripQuery().where(eq(tripsTable.id, id));
    res.json(row);
  } catch (err) {
    req.log.error({ err }, "Update trip commission error");
    res.status(500).json({ error: "Internal server error" });
  }
});

function calcNetLoadIncome(load: {
  freight: string | null;
  loadingCharges: string | null;
  unloadingCharges: string | null;
  brokerCommission: string | null;
}): number {
  return (
    Number(load.freight ?? 0) +
    Number(load.loadingCharges ?? 0) +
    Number(load.unloadingCharges ?? 0) -
    Number(load.brokerCommission ?? 0)
  );
}

router.get("/:id/loads", async (req: Request, res: Response) => {
  try {
    const id = parseId(req, res);
    if (id === null) return;

    const [trip] = await db.select({ id: tripsTable.id }).from(tripsTable).where(eq(tripsTable.id, id));
    if (!trip) {
      res.status(404).json({ error: "Trip not found" });
      return;
    }

    const rows = await db
      .select({
        id: tripLoadsTable.id,
        tripId: tripLoadsTable.tripId,
        biltyNumber: tripLoadsTable.biltyNumber,
        customerId: tripLoadsTable.customerId,
        customerName: customersTable.name,
        itemDescription: tripLoadsTable.itemDescription,
        weight: tripLoadsTable.weight,
        freight: tripLoadsTable.freight,
        loadingCharges: tripLoadsTable.loadingCharges,
        unloadingCharges: tripLoadsTable.unloadingCharges,
        brokerCommission: tripLoadsTable.brokerCommission,
        createdAt: tripLoadsTable.createdAt,
      })
      .from(tripLoadsTable)
      .innerJoin(customersTable, eq(tripLoadsTable.customerId, customersTable.id))
      .where(eq(tripLoadsTable.tripId, id))
      .orderBy(tripLoadsTable.id);

    const loads = rows.map((r) => ({
      ...r,
      netLoadIncome: calcNetLoadIncome(r),
    }));

    let totalFreight = 0;
    let totalLoadingCharges = 0;
    let totalUnloadingCharges = 0;
    let totalBrokerCommission = 0;
    for (const l of rows) {
      totalFreight += Number(l.freight ?? 0);
      totalLoadingCharges += Number(l.loadingCharges ?? 0);
      totalUnloadingCharges += Number(l.unloadingCharges ?? 0);
      totalBrokerCommission += Number(l.brokerCommission ?? 0);
    }

    res.json({
      loads,
      summary: {
        totalFreight,
        totalLoadingCharges,
        totalUnloadingCharges,
        totalBrokerCommission,
        tripIncome: totalFreight + totalLoadingCharges + totalUnloadingCharges - totalBrokerCommission,
      },
    });
  } catch (err) {
    req.log.error({ err }, "List trip loads error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/:id/loads", async (req: Request, res: Response) => {
  try {
    const id = parseId(req, res);
    if (id === null) return;

    const [trip] = await db.select().from(tripsTable).where(eq(tripsTable.id, id));
    if (!trip) {
      res.status(404).json({ error: "Trip not found" });
      return;
    }
    if (trip.status === "Closed") {
      res.status(400).json({ error: "Cannot add load to a closed trip" });
      return;
    }

    const { biltyNumber, customerId, itemDescription, weight, freight, loadingCharges, unloadingCharges, brokerCommission } = req.body;

    if (!biltyNumber || typeof biltyNumber !== "string" || !biltyNumber.trim()) {
      res.status(400).json({ error: "Bilty number is required" });
      return;
    }
    const numCustomerId = Number(customerId);
    if (!Number.isInteger(numCustomerId) || numCustomerId <= 0) {
      res.status(400).json({ error: "Valid customer is required" });
      return;
    }

    function parseOptionalNumeric(val: unknown, fieldName: string): string {
      if (val === undefined || val === null || val === "") return "0";
      const n = Number(val);
      if (!Number.isFinite(n) || n < 0) {
        throw new Error(`${fieldName} must be a valid non-negative number`);
      }
      return String(val);
    }

    let parsedWeight: string | null = null;
    let parsedFreight: string;
    let parsedLoading: string;
    let parsedUnloading: string;
    let parsedCommission: string;

    try {
      if (weight !== undefined && weight !== null && weight !== "") {
        const w = Number(weight);
        if (!Number.isFinite(w) || w < 0) {
          res.status(400).json({ error: "Weight must be a valid non-negative number" });
          return;
        }
        parsedWeight = String(weight);
      }
      parsedFreight = parseOptionalNumeric(freight, "Freight");
      parsedLoading = parseOptionalNumeric(loadingCharges, "Loading charges");
      parsedUnloading = parseOptionalNumeric(unloadingCharges, "Unloading charges");
      parsedCommission = parseOptionalNumeric(brokerCommission, "Broker commission");
    } catch (validationErr: unknown) {
      res.status(400).json({ error: (validationErr as Error).message });
      return;
    }

    const [inserted] = await db
      .insert(tripLoadsTable)
      .values({
        tripId: id,
        biltyNumber: biltyNumber.trim(),
        customerId: numCustomerId,
        itemDescription: itemDescription ? String(itemDescription) : null,
        weight: parsedWeight,
        freight: parsedFreight,
        loadingCharges: parsedLoading,
        unloadingCharges: parsedUnloading,
        brokerCommission: parsedCommission,
      })
      .returning();

    const [row] = await db
      .select({
        id: tripLoadsTable.id,
        tripId: tripLoadsTable.tripId,
        biltyNumber: tripLoadsTable.biltyNumber,
        customerId: tripLoadsTable.customerId,
        customerName: customersTable.name,
        itemDescription: tripLoadsTable.itemDescription,
        weight: tripLoadsTable.weight,
        freight: tripLoadsTable.freight,
        loadingCharges: tripLoadsTable.loadingCharges,
        unloadingCharges: tripLoadsTable.unloadingCharges,
        brokerCommission: tripLoadsTable.brokerCommission,
        createdAt: tripLoadsTable.createdAt,
      })
      .from(tripLoadsTable)
      .innerJoin(customersTable, eq(tripLoadsTable.customerId, customersTable.id))
      .where(eq(tripLoadsTable.id, inserted.id));

    res.status(201).json({
      ...row,
      netLoadIncome: calcNetLoadIncome(row),
    });
  } catch (err: unknown) {
    const pgErr = err as { code?: string };
    if (pgErr.code === "23505") {
      res.status(400).json({ error: "Duplicate bilty number in this trip" });
      return;
    }
    req.log.error({ err }, "Add trip load error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.delete("/:id/loads/:loadId", async (req: Request, res: Response) => {
  try {
    const id = parseId(req, res);
    if (id === null) return;

    const loadIdRaw = Number(req.params["loadId"]);
    if (!Number.isFinite(loadIdRaw) || loadIdRaw <= 0 || !Number.isInteger(loadIdRaw)) {
      res.status(400).json({ error: "Invalid load ID" });
      return;
    }

    const [trip] = await db.select().from(tripsTable).where(eq(tripsTable.id, id));
    if (!trip) {
      res.status(404).json({ error: "Trip not found" });
      return;
    }
    if (trip.status === "Closed") {
      res.status(400).json({ error: "Cannot delete load from a closed trip" });
      return;
    }

    const [deleted] = await db
      .delete(tripLoadsTable)
      .where(and(eq(tripLoadsTable.id, loadIdRaw), eq(tripLoadsTable.tripId, id)))
      .returning();

    if (!deleted) {
      res.status(404).json({ error: "Load not found" });
      return;
    }

    res.json({ message: "Load deleted successfully" });
  } catch (err) {
    req.log.error({ err }, "Delete trip load error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/:id/expenses", async (req: Request, res: Response) => {
  try {
    const id = parseId(req, res);
    if (id === null) return;

    const [trip] = await db.select({ id: tripsTable.id }).from(tripsTable).where(eq(tripsTable.id, id));
    if (!trip) {
      res.status(404).json({ error: "Trip not found" });
      return;
    }

    const rows = await db
      .select({
        id: tripExpensesTable.id,
        tripId: tripExpensesTable.tripId,
        expenseTypeId: tripExpensesTable.expenseTypeId,
        expenseTypeName: expenseTypesTable.name,
        amount: tripExpensesTable.amount,
        expenseDate: tripExpensesTable.expenseDate,
        expenseCategory: tripExpensesTable.expenseCategory,
        customerId: tripExpensesTable.customerId,
        customerName: customersTable.name,
        notes: tripExpensesTable.notes,
        createdAt: tripExpensesTable.createdAt,
      })
      .from(tripExpensesTable)
      .innerJoin(expenseTypesTable, eq(tripExpensesTable.expenseTypeId, expenseTypesTable.id))
      .leftJoin(customersTable, eq(tripExpensesTable.customerId, customersTable.id))
      .where(eq(tripExpensesTable.tripId, id))
      .orderBy(tripExpensesTable.expenseDate);

    let totalExpense = 0;
    for (const r of rows) {
      totalExpense += Number(r.amount ?? 0);
    }

    res.json({ expenses: rows, totalExpense });
  } catch (err) {
    req.log.error({ err }, "List trip expenses error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/:id/expenses", async (req: Request, res: Response) => {
  try {
    const id = parseId(req, res);
    if (id === null) return;

    const [trip] = await db.select().from(tripsTable).where(eq(tripsTable.id, id));
    if (!trip) {
      res.status(404).json({ error: "Trip not found" });
      return;
    }
    if (trip.status === "Closed") {
      res.status(400).json({ error: "Cannot add expense to a closed trip" });
      return;
    }

    const { expenseTypeId, amount, expenseDate, expenseCategory, customerId, notes } = req.body;

    const numExpenseTypeId = Number(expenseTypeId);
    if (!Number.isInteger(numExpenseTypeId) || numExpenseTypeId <= 0) {
      res.status(400).json({ error: "Valid expense type is required" });
      return;
    }

    const numAmount = Number(amount);
    if (!Number.isFinite(numAmount) || numAmount <= 0) {
      res.status(400).json({ error: "Amount must be greater than 0" });
      return;
    }

    if (!expenseDate || typeof expenseDate !== "string") {
      res.status(400).json({ error: "Expense date is required" });
      return;
    }

    const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
    if (!dateRegex.test(expenseDate) || isNaN(Date.parse(expenseDate))) {
      res.status(400).json({ error: "Expense date must be a valid date (YYYY-MM-DD)" });
      return;
    }

    const validCategories = ["driver", "truck", "customer"];
    if (!expenseCategory || !validCategories.includes(expenseCategory)) {
      res.status(400).json({ error: "Expense category must be one of: driver, truck, customer" });
      return;
    }

    let numCustomerId: number | null = null;
    if (expenseCategory === "customer") {
      numCustomerId = Number(customerId);
      if (!Number.isInteger(numCustomerId) || numCustomerId <= 0) {
        res.status(400).json({ error: "Customer is required when expense is for Customer" });
        return;
      }
      const [cust] = await db
        .select({ id: customersTable.id })
        .from(customersTable)
        .where(eq(customersTable.id, numCustomerId))
        .limit(1);
      if (!cust) {
        res.status(400).json({ error: "Customer not found" });
        return;
      }
    }

    const [expenseType] = await db
      .select({ id: expenseTypesTable.id })
      .from(expenseTypesTable)
      .where(eq(expenseTypesTable.id, numExpenseTypeId))
      .limit(1);
    if (!expenseType) {
      res.status(400).json({ error: "Expense type not found" });
      return;
    }

    const [inserted] = await db
      .insert(tripExpensesTable)
      .values({
        tripId: id,
        expenseTypeId: numExpenseTypeId,
        amount: String(numAmount),
        expenseDate: expenseDate,
        expenseCategory: expenseCategory,
        customerId: numCustomerId,
        notes: notes ? String(notes) : null,
      })
      .returning();

    const [row] = await db
      .select({
        id: tripExpensesTable.id,
        tripId: tripExpensesTable.tripId,
        expenseTypeId: tripExpensesTable.expenseTypeId,
        expenseTypeName: expenseTypesTable.name,
        amount: tripExpensesTable.amount,
        expenseDate: tripExpensesTable.expenseDate,
        expenseCategory: tripExpensesTable.expenseCategory,
        customerId: tripExpensesTable.customerId,
        customerName: customersTable.name,
        notes: tripExpensesTable.notes,
        createdAt: tripExpensesTable.createdAt,
      })
      .from(tripExpensesTable)
      .innerJoin(expenseTypesTable, eq(tripExpensesTable.expenseTypeId, expenseTypesTable.id))
      .leftJoin(customersTable, eq(tripExpensesTable.customerId, customersTable.id))
      .where(eq(tripExpensesTable.id, inserted.id));

    res.status(201).json(row);
  } catch (err) {
    req.log.error({ err }, "Add trip expense error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.delete("/:id/expenses/:expenseId", async (req: Request, res: Response) => {
  try {
    const id = parseId(req, res);
    if (id === null) return;

    const expenseIdRaw = Number(req.params["expenseId"]);
    if (!Number.isFinite(expenseIdRaw) || expenseIdRaw <= 0 || !Number.isInteger(expenseIdRaw)) {
      res.status(400).json({ error: "Invalid expense ID" });
      return;
    }

    const [trip] = await db.select().from(tripsTable).where(eq(tripsTable.id, id));
    if (!trip) {
      res.status(404).json({ error: "Trip not found" });
      return;
    }
    if (trip.status === "Closed") {
      res.status(400).json({ error: "Cannot delete expense from a closed trip" });
      return;
    }

    const [deleted] = await db
      .delete(tripExpensesTable)
      .where(and(eq(tripExpensesTable.id, expenseIdRaw), eq(tripExpensesTable.tripId, id)))
      .returning();

    if (!deleted) {
      res.status(404).json({ error: "Expense not found" });
      return;
    }

    res.json({ message: "Expense deleted successfully" });
  } catch (err) {
    req.log.error({ err }, "Delete trip expense error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/:id/customer-payments", async (req: Request, res: Response) => {
  try {
    const id = parseId(req, res);
    if (!id) return;

    const [trip] = await db.select().from(tripsTable).where(eq(tripsTable.id, id));
    if (!trip) { res.status(404).json({ error: "Trip not found" }); return; }

    const payments = await db
      .select()
      .from(customerPaymentsTable)
      .where(eq(customerPaymentsTable.tripId, id))
      .orderBy(customerPaymentsTable.paymentDate);

    const totalReceived = payments.reduce((sum, p) => sum + Number(p.amount), 0);

    res.json({ payments, totalReceived });
  } catch (err) {
    req.log.error({ err }, "List customer payments error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/:id/customer-dues", async (req: Request, res: Response) => {
  try {
    const id = parseId(req, res);
    if (!id) return;

    const [trip] = await db.select().from(tripsTable).where(eq(tripsTable.id, id));
    if (!trip) { res.status(404).json({ error: "Trip not found" }); return; }

    const rows = await db
      .select({
        id: customerDuesTable.id,
        tripId: customerDuesTable.tripId,
        loadId: customerDuesTable.loadId,
        customerId: customerDuesTable.customerId,
        customerName: customersTable.name,
        biltyNumber: customerDuesTable.biltyNumber,
        dueAmount: customerDuesTable.dueAmount,
        paidAmount: customerDuesTable.paidAmount,
        balance: sql<number>`(${customerDuesTable.dueAmount}::numeric - ${customerDuesTable.paidAmount}::numeric)::double precision`.as("balance"),
        dueDate: customerDuesTable.dueDate,
        status: customerDuesTable.status,
        notes: customerDuesTable.notes,
      })
      .from(customerDuesTable)
      .innerJoin(customersTable, eq(customerDuesTable.customerId, customersTable.id))
      .where(eq(customerDuesTable.tripId, id))
      .orderBy(sql`${customerDuesTable.dueDate} DESC`);

    const totalDue = rows.reduce((sum, r) => sum + Number(r.dueAmount), 0);
    const totalPaid = rows.reduce((sum, r) => sum + Number(r.paidAmount), 0);
    const totalBalance = rows.reduce((sum, r) => sum + (r.balance ?? 0), 0);

    res.json({ dues: rows, totalDue, totalPaid, totalBalance });
  } catch (err) {
    req.log.error({ err }, "List trip customer dues error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/:id/customer-payments", async (req: Request, res: Response) => {
  try {
    const id = parseId(req, res);
    if (!id) return;

    const [trip] = await db.select().from(tripsTable).where(eq(tripsTable.id, id));
    if (!trip) { res.status(404).json({ error: "Trip not found" }); return; }

    if (trip.status === "Closed") {
      res.status(400).json({ error: "Cannot add payments to a closed trip. Use Customer Dues to manage remaining amounts." });
      return;
    }

    const { amount, paymentDate, paymentMode, notes, customerId } = req.body;

    const numAmount = Number(amount);
    if (!Number.isFinite(numAmount) || numAmount <= 0) {
      res.status(400).json({ error: "Amount must be greater than 0" });
      return;
    }

    if (!paymentDate || typeof paymentDate !== "string") {
      res.status(400).json({ error: "Payment date is required" });
      return;
    }

    const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
    if (!dateRegex.test(paymentDate) || isNaN(Date.parse(paymentDate))) {
      res.status(400).json({ error: "Payment date must be valid (YYYY-MM-DD)" });
      return;
    }

    const custId = customerId ? Number(customerId) : null;
    if (!custId || !Number.isInteger(custId) || custId <= 0) {
      res.status(400).json({ error: "Customer is required" });
      return;
    }

    const result = await db.transaction(async (tx) => {
      const [payment] = await tx
        .insert(customerPaymentsTable)
        .values({
          tripId: id,
          customerId: custId,
          amount: String(numAmount),
          paymentDate,
          paymentMode: paymentMode ? String(paymentMode) : null,
          notes: notes ? String(notes) : null,
        })
        .returning();

      await tx.insert(cashBookTable).values({
        entryType: "IN",
        referenceTable: "customer_payments",
        referenceId: payment.id,
        amount: String(numAmount),
        entryDate: paymentDate,
        description: `Customer payment for Trip #${id}${paymentMode ? ` (${paymentMode})` : ""}`,
      });

      return payment;
    });

    res.status(201).json(result);
  } catch (err) {
    req.log.error({ err }, "Add customer payment error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/:id/driver-advances", async (req: Request, res: Response) => {
  try {
    const id = parseId(req, res);
    if (!id) return;

    const [trip] = await db.select().from(tripsTable).where(eq(tripsTable.id, id));
    if (!trip) { res.status(404).json({ error: "Trip not found" }); return; }

    const advances = await db
      .select()
      .from(driverAdvancesTable)
      .where(eq(driverAdvancesTable.tripId, id))
      .orderBy(driverAdvancesTable.advanceDate);

    const totalAdvances = advances.reduce((sum, a) => sum + Number(a.amount), 0);

    res.json({ advances, totalAdvances });
  } catch (err) {
    req.log.error({ err }, "List driver advances error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/:id/driver-advances", async (req: Request, res: Response) => {
  try {
    const id = parseId(req, res);
    if (!id) return;

    const [trip] = await db.select({ id: tripsTable.id, driverId: tripsTable.driverId, status: tripsTable.status })
      .from(tripsTable).where(eq(tripsTable.id, id));
    if (!trip) { res.status(404).json({ error: "Trip not found" }); return; }

    if (trip.status !== "Open") {
      res.status(400).json({ error: "Driver advances can only be added to open trips" });
      return;
    }

    const { amount, advanceDate, notes } = req.body;

    const numAmount = Number(amount);
    if (!Number.isFinite(numAmount) || numAmount <= 0) {
      res.status(400).json({ error: "Amount must be greater than 0" });
      return;
    }

    if (!advanceDate || typeof advanceDate !== "string") {
      res.status(400).json({ error: "Advance date is required" });
      return;
    }

    const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
    if (!dateRegex.test(advanceDate) || isNaN(Date.parse(advanceDate))) {
      res.status(400).json({ error: "Advance date must be valid (YYYY-MM-DD)" });
      return;
    }

    const result = await db.transaction(async (tx) => {
      const [advance] = await tx
        .insert(driverAdvancesTable)
        .values({
          driverId: trip.driverId,
          tripId: id,
          amount: String(numAmount),
          advanceDate,
          notes: notes ? String(notes) : null,
        })
        .returning();

      await tx.insert(cashBookTable).values({
        entryType: "OUT",
        referenceTable: "driver_advances",
        referenceId: advance.id,
        amount: String(numAmount),
        entryDate: advanceDate,
        description: `Driver advance for Trip #${id}`,
      });

      return advance;
    });

    res.status(201).json(result);
  } catch (err) {
    req.log.error({ err }, "Add driver advance error");
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
